# AFLNaturalLanguageQueryBuilder

The goal is to build a relational database of afl stats and build (or use) a model that can translate natural language into a db query.

<https://python.langchain.com/docs/use_cases/qa_structured/sql>
